export class Notice {
    constructor(public title: string, public content: string, public contact: string, public date: Date) {}
  }
  